import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Cart = ({ token }) => {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    if (token) {
      axios.get('http://localhost:5000/api/cart', {
        headers: { Authorization: `Bearer ${token}` },
      }).then(res => setCart(res.data.cart));
    }
  }, [token]);

  return (
    <div className="cart-section">
      <h2>Cart Items</h2>
      {cart.length === 0 ? (
        <p>Cart is empty</p>
      ) : (
        <ul>
          {cart.map(item => (
            <li key={item._id}>{item.name} - ৳{item.price}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Cart;
