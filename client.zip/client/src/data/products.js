const products = [
  {
    id: 1,
    name: 'Classic Shirt',
    price: 40,
    category: 'Shirts',
    image: '/images/shirt1.jpg',
  },
  {
    id: 2,
    name: 'Blue Jeans',
    price: 50,
    category: 'Jeans',
    image: '/images/jeans1.jpg',
  },
  // Add more as needed
];

export default products;
